# StickerBridge

Aplicación Android nativa en Kotlin + Jetpack Compose para preparar stickers recibidos con el Sharesheet de Android y compartirlos hacia WhatsApp u otra aplicación.

## Fuentes oficiales consultadas

- TikTok OAuth for Minis / OAuth v2: https://developers.tiktok.com/doc/minis-oauth?enter_method=left_navigation
- WhatsApp Business Platform — Sticker messages: https://developers.facebook.com/documentation/business-messaging/whatsapp/messages/sticker-messages

## Alcance honesto

StickerBridge **no accede a bases de datos privadas**, no hace scraping y nunca solicita contraseñas. A fecha de esta implementación:

- TikTok dispone de productos oficiales de autenticación/API para casos aprobados, pero no existe una API pública documentada para leer la colección personal de stickers. Por eso el proyecto no inventa un endpoint ni marca TikTok como conectado: el flujo soportado es **TikTok → Compartir → StickerBridge**.
- WhatsApp Business Platform documenta mensajería de stickers para cuentas Business, no acceso a la colección personal de stickers de la aplicación WhatsApp. Este proyecto usa Android `ACTION_SEND`, `ACTION_SEND_MULTIPLE`, `FileProvider` y el Sharesheet; no usa la API Business para fingir acceso personal.

La app procesa localmente WebP, PNG, JPEG, GIF y MP4. En esta primera versión la conversión segura es una normalización/copia local; los formatos se validan antes de exportar. El video se conserva como MP4 para que el destino compatible decida cómo manejarlo.

## Ejecutar

1. Abre el proyecto en Android Studio (JDK 17).
2. Ejecuta `./gradlew lint testDebugUnitTest assembleDebug`.
3. Instala `app/build/outputs/apk/debug/app-debug.apk`.
4. En TikTok o WhatsApp usa **Compartir** y elige StickerBridge; también puedes usar el selector interno.

## Arquitectura

`presentation` (Compose + ViewModel + StateFlow) → `processor` (validación y procesamiento local) → `domain` (modelos). La exportación usa `FileProvider` con permisos URI temporales.

## Privacidad y seguridad

No hay servidor propio, credenciales, cookies ni contraseñas. Los URI recibidos son temporales y se copian al almacenamiento privado de la app. Revisa y revoca los permisos de URI desde Android cuando corresponda.

## CI / release

- `android-ci.yml`: lint, tests unitarios y APK debug.
- `release.yml`: al publicar un tag `v*`, compila release y sube el APK como artefacto de GitHub Release. No firma con un keystore incluido; configura `SIGNING_*` como secrets si necesitas firma de producción.

## Licencia

Apache-2.0. Consulta `LICENSE`.
